package in.arjun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaConsumerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
